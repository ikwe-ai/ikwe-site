# Study II Notion Intake System (v1.0 canonical)

This document defines the Notion database schemas for Study II: Mechanism-Based Analysis.

Principle:
- GitHub (or your local canonical archive) remains the long-term record.
- Notion is the workflow database (cases -> excerpts -> scenarios) and a partner-friendly mirror.
- Do not store procedural self-harm content verbatim in Notion.

## Database A: StudyII_Cases
Purpose: Registry of publicly documented cases (lawsuits, official reports, high-quality investigations). This is not a transcript store.

### Required properties (create exactly)
1) Name
- Type: Title
- Format: "C-01 - Short case label"

2) Case_ID
- Type: Text
- Example: C-01

3) Platform
- Type: Select
- Values: OpenAI/ChatGPT, Character.AI, Other

4) Source_Type
- Type: Select
- Values: Court filing, Official report, Investigative journalism, Regulatory filing, Company report

5) Outcome_Category
- Type: Select
- Values: Fatal, Near-fatal, Litigation-only, Other severe harm

6) Jurisdiction
- Type: Text
- Example: US-CA, US-TX, US-OR, US-FL

7) Event_Date
- Type: Date
- Notes: Date of the incident (if known/public)

8) Filing_Date
- Type: Date
- Notes: Date the complaint/report was filed/published (if known/public)

9) Primary_Source
- Type: URL
- Notes: Link to the complaint/report PDF (or authoritative host)

10) Secondary_Sources
- Type: Text (long)
- Notes: Additional reporting references (one per line)

11) Public_Transcript_Available
- Type: Select
- Values: Yes (excerpts), Yes (exhibits), No, Unknown

12) Mechanism_Tags
- Type: Multi-select
- Values (suggested, align to Study I dimensions):
  - RA (Risk amplification)
  - IR (Isolation reinforcement)
  - RTF (Reality testing failure)
  - DCF (Duty of care failure)
  - RQF (Repair quality failure)
  - AC (Authority capture / over-deference)
  - RL (Relational lock-in / exclusivity)
  - DEL (Delayed intervention)

13) Notes_Safe
- Type: Text (long)
- Notes: Non-procedural summary only.

14) Status
- Type: Select
- Values: Candidate, Verified, Abstracted, Excluded
- Default: Candidate

15) Canonical_Version
- Type: Text
- Default: v1.0

16) Intake_Date
- Type: Date
- Default: today

### Recommended views
- Verified cases: Status = Verified
- Ready to abstract: Status = Verified AND Public_Transcript_Available contains "Yes"
- Needs source: Status = Candidate AND Primary_Source is empty


## Database B: StudyII_Excerpts
Purpose: Register of specific, citable excerpt segments from primary/secondary sources. Store only what is needed to support abstraction and scoring, and redact/avoid procedural details.

### Required properties
1) Name
- Type: Title
- Format: "E-01 - C-01 - short label"

2) Excerpt_ID
- Type: Text
- Example: E-01

3) Case
- Type: Relation
- Relation: StudyII_Cases

4) Source_Document
- Type: Select
- Values: Complaint/PDF, Exhibit, Reporting, Other

5) Citation_Locator
- Type: Text
- Example: "Exhibit A, p. 12" or "Para 197" or "Article section: ..."

6) Excerpt_Text_Safe
- Type: Text (long)
- Rules: No procedural self-harm instructions. Use redaction tokens like [REDACTED-PROCEDURE].

7) Speaker_Pattern
- Type: Select
- Values: User->Assistant, Assistant only, Mixed/unclear

8) Mechanism_Tags
- Type: Multi-select
- Use same values as Cases

9) Redaction_Level
- Type: Select
- Values: None, Light, Heavy

10) Verified
- Type: Checkbox
- Rule: Check only if Citation_Locator + Source_Document are complete.

11) Notes
- Type: Text (long)


## Database C: StudyII_Scenarios
Purpose: The research-safe scenario objects you will actually run through models.

### Required properties
1) Name
- Type: Title
- Format: "S2-01 - short label"

2) Scenario_ID
- Type: Text
- Example: S2-01

3) Derived_From
- Type: Relation
- Relation: StudyII_Excerpts

4) Status
- Type: Select
- Values: Draft, Locked
- Default: Draft

5) Canonical_Version
- Type: Text
- Default: v1.0

6) Scenario_Text
- Type: Text (long)
- Rules: Research-safe abstraction, no reenactment, no procedural content.

7) Vulnerability_Profile
- Type: Multi-select
- Values (suggested): anxiety, depression, ideation (non-procedural), paranoia/delusion risk, isolation, substance use context, relationship conflict, medical anxiety

8) Target_Mechanisms
- Type: Multi-select
- Use same mechanism values

9) K_Window
- Type: Number
- Default: your locked K

10) Notes
- Type: Text (long)

### Recommended views
- Draft scenarios: Status = Draft
- Ready to run: Status = Locked
- By mechanism: grouped by Target_Mechanisms
