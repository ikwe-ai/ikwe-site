# IKWE.AI MEDIA KIT

## Company Boilerplate

**Ikwe.ai** is an AI safety research company focused on behavioral emotional safety — how AI systems behave when humans are emotionally vulnerable. Founded in Des Moines, Iowa, Ikwe develops both applied emotionally intelligent AI systems and the measurement infrastructure needed to evaluate them responsibly.

The company's EQ Safety Benchmark evaluates observable behavioral patterns in conversational AI under emotional load, measuring whether systems stabilize users or introduce risk over time. Unlike benchmarks focused on emotion recognition or policy compliance, Ikwe's framework tests behavioral consistency across extended vulnerable interactions.

**Parent company:** Visible Healing Inc.  
**Location:** Des Moines, Iowa  
**Founded:** 2024  
**Focus:** Behavioral emotional safety in AI

---

## Key Research Finding

In January 2026, Ikwe released findings from the EQ Safety Benchmark v1, evaluating frontier AI models across 79 emotionally-charged scenarios:

- **54.7%** of baseline model responses introduced emotional risk patterns
- Baseline models scored **1.7/5** on Regulation Before Reasoning (the benchmark's highest-weighted dimension)
- An emotionally intelligent prototype showed **lower variance** and greater behavioral stability after passing baseline safety criteria

These findings describe behavioral patterns under test conditions — they do not imply real-world harm, intent, or deployment readiness.

---

## Core Thesis

> "Recognition ≠ Safety"

AI systems optimized for emotional articulation often show greater variance on emotional safety measures. The ability to recognize and respond to emotion does not guarantee safe behavior as vulnerability deepens.

---

## Contact

**Press inquiries:** research@ikwe.ai  
**Website:** https://ikwe.ai  
**Research:** https://ikwe.ai/research

---

## Attribution

Quotes may be attributed to **Ikwe.ai Research** unless otherwise specified.

**Short citation:**  
Ikwe.ai, *Behavioral Emotional Safety in Conversational AI*, 2026.

**Full citation:**  
Ikwe.ai (2026). *Behavioral Emotional Safety in Conversational AI: A Scenario-Based Evaluation.* Public Research Summary. https://ikwe.ai/research

---

*© 2026 Visible Healing Inc. All rights reserved.*
