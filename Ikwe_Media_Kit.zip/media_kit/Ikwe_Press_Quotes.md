# IKWE.AI — APPROVED PRESS QUOTES

## Attribution
All quotes may be attributed to **"Ikwe.ai Research"** unless otherwise specified.

---

## Core Findings

### On the central insight:
> "AI systems can recognize emotion and still behave unsafely once vulnerability deepens."

### On why benchmarks fail:
> "Most benchmarks test whether AI understands emotion. Very few test whether it remains safe over time."

### On the EI prototype:
> "The difference wasn't expressiveness — it was consistency."

### On the Safety Gate:
> "Starting safe is not the same as staying safe."

---

## Scope & Limitations

### On scope:
> "These findings describe behavioral patterns under test conditions, not real-world outcomes."

### On the gap:
> "Emotional capability without behavioral stability introduces risk at scale."

### On methodology:
> "This benchmark evaluates how AI systems behave under emotional load — not just whether they recognize emotion."

---

## Key Statistics (For Context)

| Statistic | Value | Population |
|-----------|-------|------------|
| Introduced emotional risk | 54.7% | Baseline frontier models only (n=234) |
| EI prototype safety pass rate | 84.6% | All EI prototype responses (n=78) |
| Baseline regulation score | 1.7/5 | Baseline models that passed Safety Gate |
| EI prototype regulation score | 4.05/5 | EI responses that passed Safety Gate |

**Important:** "Introduced emotional risk" does NOT mean harm occurred. It means the response contained behavioral patterns associated with increased risk under the benchmark's criteria.

---

## Citation Formats

### Short:
Ikwe.ai, *Behavioral Emotional Safety in Conversational AI*, 2026.

### Full:
Ikwe.ai (2026). *Behavioral Emotional Safety in Conversational AI: A Scenario-Based Evaluation.* Public Research Summary. https://ikwe.ai/research

---

## Contact

**For press inquiries:** research@ikwe.ai  
**Website:** https://ikwe.ai  
**Full research:** https://ikwe.ai/research

---

*Visible Healing Inc. · ikwe.ai · Des Moines, Iowa*
