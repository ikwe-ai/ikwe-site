# IKWE.AI MEDIA KIT

## Contents

This media kit contains materials for press, policy, and academic citation.

### Files Included

| File | Description |
|------|-------------|
| `Ikwe_Behavioral_Emotional_Safety_Research_2026.pdf` | Full 11-page public research summary with methodology, findings, and figures |
| `Ikwe_Press_Visual_Sheet.pdf` | One-page visual summary with key stats and charts (designed for publication) |
| `Ikwe_Press_Quotes.md` | Pre-approved quotes organized by topic with attribution guidance |
| `Ikwe_Boilerplate.md` | Company description and key finding summary for articles |

---

## Usage Guidelines

### For Journalists

- Figures and quotes are designed to stand alone without additional interpretation
- All quotes may be attributed to **"Ikwe.ai Research"**
- Statistics include population context — please preserve this when citing
- Contact research@ikwe.ai for clarification or additional materials

### For Academics

- Use the full citation format for papers and reports
- The research summary is designed for citation but does not include reproducibility details
- Scenario-level data is available to approved researchers upon request

### For Policy

- Findings describe behavioral patterns under test conditions
- They do not constitute deployment recommendations or clinical assessments
- Contact us for regulatory-specific briefings

---

## Key Statistics (With Context)

| Statistic | Value | Population |
|-----------|-------|------------|
| Introduced emotional risk | 54.7% | Baseline frontier models only (n=234 responses) |
| EI prototype safety pass rate | 84.6% | All EI prototype responses (n=78) |
| Baseline regulation score | 1.7/5 | Baseline models that passed Safety Gate |
| EI prototype regulation score | 4.05/5 | EI responses that passed Safety Gate |

**Important:** "Introduced emotional risk" does NOT mean harm occurred. It means the response contained behavioral patterns associated with increased risk under the benchmark's criteria.

---

## Citation Formats

**Short:**
```
Ikwe.ai, Behavioral Emotional Safety in Conversational AI, 2026.
```

**Full:**
```
Ikwe.ai (2026). Behavioral Emotional Safety in Conversational AI: 
A Scenario-Based Evaluation. Public Research Summary. 
https://ikwe.ai/research
```

---

## Contact

**Press inquiries:** research@ikwe.ai  
**Website:** https://ikwe.ai  
**Research page:** https://ikwe.ai/research  
**Press page:** https://ikwe.ai/press

---

*© 2026 Visible Healing Inc. All rights reserved.*
*Des Moines, Iowa*
